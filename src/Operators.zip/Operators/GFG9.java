package Operators;

//Java Program to implement
//shift operators
import java.io.*;

//Driver Class

public class GFG9 {
 // main function
 public static void main(String[] args)
 {
     int a = 10;
 
       // using left shift
     System.out.println("a<<1 : " + (a << 1));
   
     // using right shift
     System.out.println("a>>1 : " + (a >> 1));
 }
}
