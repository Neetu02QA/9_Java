package Operators;


//Drive Class
public class GFG1 {

	public static void main(String[] args) {
		// Arithmetic operators
		   int a = 10;
		   int b = 3;
		 
		   System.out.println("a + b = " + (a + b));
		   System.out.println("a - b = " + (a - b));
		   System.out.println("a * b = " + (a * b));
		   System.out.println("a / b = " + (a / b));
		   System.out.println("a % b = " + (a % b));
	}

}

