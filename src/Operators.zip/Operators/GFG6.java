package Operators;

//Java Program to implemenet
//Logical operators
import java.io.*;

//Driver Class
public class GFG6 {
// Main Function
public static void main (String[] args) {
 // Logical operators
 boolean x = true;
 boolean y = false;

 System.out.println("x && y: " + (x && y));
 System.out.println("x || y: " + (x || y));
 System.out.println("!x: " + (!x));
}
}
