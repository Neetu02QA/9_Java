package JavaManipulations;

public class Length_of_String_5 {

	public static void main(String[] args) {
		
		String s1 = "hello World!";
		
		System.out.println("string length is: "+s1.length());

	}

}
