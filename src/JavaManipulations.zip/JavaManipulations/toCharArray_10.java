package JavaManipulations;

public class toCharArray_10 {
	
	public static void main(String[] args) {
		
		String s1 = "Hello";
		char[] ch = s1.toCharArray();
		
		//converts this string into character array
		for(int i=0;i<ch.length;i++)
		{
			System.out.println(ch[i]);
		}
		
	}

}
