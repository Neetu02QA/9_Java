package JavaManipulations;

public class charAt_contains_6 {

	public static void main(String[] args) {
		
		String name = "hello World!";
		
		//charAt ()
		char ch = name.charAt(4);
		System.out.println(ch);//At forth postion is o letter
		
		//contains ()
		System.out.println(name.contains("Hello"));
		System.out.println(name.contains("hello"));
		
		
		
		
		

	}

}
