package JavaManipulations;

public class oper {

	public static void main(String[] args) {
		

	}

}
