package JavaManipulations;

public class lowercase_uppercase_11 {

	public static void main(String[] args) {
		
		String s1 = "My name is Salman";
		
		//to lowercase
		String lower = s1.toLowerCase();
		System.out.println(lower);
		
		// to uppercase
		String upper = s1.toUpperCase();
		System.out.println(upper);
			
	

	}

}
