package JavaManipulations;

public class Substring_4 {

	public static void main(String[] args) {
		
		String s = "Hello World";
		System.out.println(s.substring(6));
		System.out.println(s.substring(0,5));
		

	}

}
